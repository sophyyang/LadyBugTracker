Welcome to our LadyBug Tracker. A simple tracking system for all your bug tickets!

Sophy added January 16, 2016 11:59AM
Importing a GitHub project into Eclipse:
1.Fork from Katie's LadyBug Tracker https://github.com/katiemsullivan/LadyBugTracker.git
2.From Eclipse menu (File->Import->General->Existing Projects into Workspace)
