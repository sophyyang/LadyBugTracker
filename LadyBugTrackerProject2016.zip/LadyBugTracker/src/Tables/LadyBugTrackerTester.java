package Tables;

import java.sql.SQLException;
import java.util.ArrayList;

public class LadyBugTrackerTester {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		LadyBugData rsList = new LadyBugData();
		//System.out.println("Done Lady Bug Tracker Tester");
		//System.out.println(rsList.LadyBugItems(2));
		//System.out.println(rsList.LadyBugDropDownList());
		System.out.println(rsList.LadyBugUser());
		
		
		

	}

}
