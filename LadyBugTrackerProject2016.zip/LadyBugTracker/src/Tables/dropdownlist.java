package Tables;

public class dropdownlist {
	private 	int dropdownListID;
	private 	String description;
	

	public int getDropdownListID() {
		return dropdownListID;
	}
	public void setDropdownListID(int dropdownListID) {
		this.dropdownListID = dropdownListID;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	

	
}
